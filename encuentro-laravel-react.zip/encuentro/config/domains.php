<?php
return ['verification_days'=>7,'acme_email'=>env('ACME_EMAIL','')];
